export interface ICandy {
  select: number;
  name: string;
  value: number;
}
