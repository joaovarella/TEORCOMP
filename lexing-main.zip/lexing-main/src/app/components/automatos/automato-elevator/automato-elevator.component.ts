import { Component } from '@angular/core';

@Component({
  selector: 'app-automato',
  standalone: true,
  imports: [],
  templateUrl: './automato-elevator.component.html',
  styleUrl: './automato-elevator.component.scss'
})
export class AutomatoElevatorComponent {

}
