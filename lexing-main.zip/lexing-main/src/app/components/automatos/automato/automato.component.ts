import { Component } from '@angular/core';

@Component({
  selector: 'app-automato',
  standalone: true,
  imports: [],
  templateUrl: './automato.component.html',
  styleUrl: './automato.component.scss'
})
export class AutomatoComponent {

}
