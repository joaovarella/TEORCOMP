# Lexing

## Objetivo
Projeto desenvolvido na UC de Teoria da computação e compiladores com objetivo de criar um analisador léxico de compilador

## Link
[Link para o projeto](https://lexing.vercel.app/)

## Status
Em Andamento

## Tecnologias
Angular
TypeScript
SCSS
